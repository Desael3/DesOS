/* SPDX-License-Identifier: 0BSD */

/* Copyright (C) 2022-2026 Mintsuki and contributors.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __FREESTANDING_C_HDRS_ISO646_H
#define __FREESTANDING_C_HDRS_ISO646_H 1

#pragma GCC system_header

#include <__freestanding_c_hdrs/revision.h>

#if __FREESTANDING_C_HDRS_ISO646_REVISION < 199409L
#  error "<iso646.h> requires C95 or later"
#endif

/* C++ has these names as operators. */
#ifndef __cplusplus

#undef and
#define and &&
#undef and_eq
#define and_eq &=
#undef bitand
#define bitand &
#undef bitor
#define bitor |
#undef compl
#define compl ~
#undef not
#define not !
#undef not_eq
#define not_eq !=
#undef or
#define or ||
#undef or_eq
#define or_eq |=
#undef xor
#define xor ^
#undef xor_eq
#define xor_eq ^=

#endif

#endif
