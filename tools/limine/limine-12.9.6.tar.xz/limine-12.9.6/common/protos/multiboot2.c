#if defined (__x86_64__) || defined (__i386__)

#include <stdint.h>
#include <stddef.h>
#include <stdnoreturn.h>
#include <protos/multiboot2.h>
#include <protos/multiboot.h>
#include <config.h>
#include <lib/libc.h>
#include <lib/elf.h>
#include <lib/misc.h>
#include <lib/config.h>
#include <lib/print.h>
#include <lib/uri.h>
#include <lib/tpm.h>
#include <lib/fb.h>
#include <lib/term.h>
#include <lib/elsewhere.h>
#include <sys/pic.h>
#include <sys/cpu.h>
#include <sys/idt.h>
#include <sys/iommu.h>
#include <sys/lapic.h>
#include <fs/file.h>
#include <mm/vmm.h>
#include <lib/acpi.h>
#include <mm/pmm.h>
#include <lib/misc.h>
#include <drivers/vga_textmode.h>
#include <pxe/pxe.h>

#define LIMINE_BRAND "Limine " LIMINE_VERSION

#define MEMMAP_MAX 256
#define EFI_MEMMAP_MAX 1024

/// Returns the size required to store the multiboot2 info.
static size_t get_multiboot2_info_size(
    char *cmdline,
    size_t modules_size,
    uint32_t section_entry_size, uint32_t section_num,
    uint32_t smbios_tag_size
) {
#define OVERFLOW panic(true, "multiboot2: info size overflow")
    return ALIGN_UP(sizeof(struct multiboot2_start_tag), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_string) + strlen(cmdline) + 1, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_string) + sizeof(LIMINE_BRAND), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_framebuffer), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_new_acpi) + sizeof(struct rsdp), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_old_acpi) + 20, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_elf_sections) + CHECKED_MUL(section_entry_size, section_num, OVERFLOW), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(modules_size, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_load_base_addr), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(smbios_tag_size, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_basic_meminfo), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag_mmap) + sizeof(struct multiboot_mmap_entry) * MEMMAP_MAX, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        #if defined (UEFI)
            ALIGN_UP(sizeof(struct multiboot_tag_efi_mmap) + (efi_desc_size * EFI_MEMMAP_MAX), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
            #if defined (__i386__)
                ALIGN_UP(sizeof(struct multiboot_tag_efi32), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
            #elif defined (__x86_64__)
                ALIGN_UP(sizeof(struct multiboot_tag_efi64), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
            #endif
        #elif defined (BIOS)
            ALIGN_UP(sizeof(struct multiboot_tag_bootdev), MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        #endif
        ALIGN_UP(sizeof(struct multiboot_tag_network) + DHCP_ACK_PACKET_LEN, MULTIBOOT_TAG_ALIGN, OVERFLOW) +
        ALIGN_UP(sizeof(struct multiboot_tag), MULTIBOOT_TAG_ALIGN, OVERFLOW);
#undef OVERFLOW
}

// elsewhere_reserve_target() can only protect what is free when the target is
// chosen, so a window holding loader allocations is not viable: whatever the
// loader frees afterwards is handed back out on top of the executable.
static bool overlaps_loader_memory(uint64_t base, uint64_t top) {
    for (size_t i = 0; i < memmap_entries; i++) {
        if (memmap[i].type != MEMMAP_BOOTLOADER_RECLAIMABLE
         && memmap[i].type != MEMMAP_KERNEL_AND_MODULES) {
            continue;
        }

        uint64_t entry_top = CHECKED_ADD(memmap[i].base, memmap[i].length, continue);

        if (memmap[i].base < top && entry_top > base) {
            return true;
        }
    }

    return false;
}

#define append_tag(P, TAG) do { \
    (P) += ALIGN_UP((TAG)->size, MULTIBOOT_TAG_ALIGN, panic(true, "multiboot2: tag size overflow")); \
} while (0)

noreturn void multiboot2_load(char *config, char* cmdline) {
    struct file_handle *kernel_file;

#if defined (UEFI)
    if (cmdline != NULL) {
        tpm_measure(TPM_PCR_BOOT_AUTH, TPM_EV_IPL,
                    cmdline, strlen(cmdline), "cmdline: ", cmdline);
    }
#endif

    char *kernel_path = config_get_value(config, 0, "PATH");
    if (kernel_path == NULL) {
        kernel_path = config_get_value(config, 0, "KERNEL_PATH");
    }
    if (kernel_path == NULL) {
        panic(true, "multiboot2: Executable path not specified");
    }

    if (!terse) {
        print("multiboot2: Loading executable `%#`...\n", kernel_path);
    }

    if ((kernel_file = uri_open(kernel_path, MEMMAP_KERNEL_AND_MODULES, false
#if defined (__i386__)
        , NULL, NULL
#endif
    )) == NULL)
        panic(true, "multiboot2: Failed to open executable with path `%#`. Is the path correct?", kernel_path);

    uint8_t *kernel = kernel_file->fd;

    size_t kernel_file_size = kernel_file->size;

#if defined (BIOS)
    struct volume *kernel_volume = kernel_file->pxe ? NULL : kernel_file->vol;
#endif

#if defined (UEFI)
    tpm_measure_path(TPM_PCR_BOOT_AUTH, TPM_EV_IPL, "path: ", kernel_path);
    tpm_measure(TPM_PCR_LOADED_IMAGES, TPM_EV_IPL,
                kernel, kernel_file_size, "path: ", kernel_path);
#endif

    fclose(kernel_file);

    struct multiboot_header *header = NULL;

    // The header must lie wholly within the first 32768 bytes, 8-byte aligned;
    // header_length says how far it reaches.
    if (kernel_file_size < sizeof(struct multiboot_header)) {
        panic(true, "multiboot2: Kernel file too small to contain header");
    }
    size_t search_end = MIN(kernel_file_size, (size_t)MULTIBOOT_SEARCH);

    for (size_t header_offset = 0; header_offset <= search_end - sizeof(struct multiboot_header);
         header_offset += MULTIBOOT_HEADER_ALIGN) {
        header = (void *)(kernel + header_offset);

        if (header->magic == MULTIBOOT2_HEADER_MAGIC) {
            break;
        }
    }

    if (header == NULL || header->magic != MULTIBOOT2_HEADER_MAGIC) {
        panic(true, "multiboot2: Invalid magic");
    }

    if (header->magic + header->architecture + header->checksum + header->header_length) {
        panic(true, "multiboot2: Header checksum is invalid");
    }

    if (header->architecture != MULTIBOOT_ARCHITECTURE_I386) {
        panic(true, "multiboot2: Unsupported architecture %u (expected i386)", header->architecture);
    }

    size_t header_offset_in_file = (uintptr_t)header - (uintptr_t)kernel;
    if (header->header_length > kernel_file_size - header_offset_in_file) {
        panic(true, "multiboot2: Header length exceeds kernel file size");
    }
    if (header->header_length > search_end - header_offset_in_file) {
        panic(true, "multiboot2: Header extends past the first 32768 bytes");
    }

    struct multiboot_header_tag_address *addresstag = NULL;
    struct multiboot_header_tag_framebuffer *fbtag = NULL;

    bool has_reloc_header = false;
    struct multiboot_header_tag_relocatable reloc_tag = {0};

#if defined (UEFI)
    bool is_framebuffer_declared = false;
    uint32_t console_flags = 0;
#endif

    uint64_t entry_point = 0xffffffff;

    // Iterate through the entries...
    for (struct multiboot_header_tag *tag = (struct multiboot_header_tag*)(header + 1); // header + 1 to skip the header struct.
       (uintptr_t)tag + sizeof(struct multiboot_header_tag) <= (uintptr_t)header + header->header_length
         && tag->type != MULTIBOOT_HEADER_TAG_END;
       ) {
        if (tag->size == 0) {
            break;
        }
        if (tag->size > (size_t)((uintptr_t)header + header->header_length - (uintptr_t)tag)) {
            panic(true, "multiboot2: Header tag exceeds header bounds");
        }
        size_t tag_stride = ALIGN_UP(tag->size, MULTIBOOT_TAG_ALIGN, break);
        bool is_required = !(tag->flags & MULTIBOOT_HEADER_TAG_OPTIONAL);
        switch (tag->type) {
            case MULTIBOOT_HEADER_TAG_INFORMATION_REQUEST: {
                // Iterate the requests and check if they are supported by or not.
                struct multiboot_header_tag_information_request *request = (void *)tag;
                if (request->size < sizeof(struct multiboot_header_tag_information_request)) {
                    panic(true, "multiboot2: Invalid information request tag size");
                }
                size_t tag_remaining = (uintptr_t)header + header->header_length - (uintptr_t)tag;
                if (request->size > tag_remaining) {
                    panic(true, "multiboot2: Information request tag exceeds header bounds");
                }
                uint32_t size = (request->size - sizeof(struct multiboot_header_tag_information_request)) / sizeof(uint32_t);

                for (uint32_t i = 0; i < size; i++) {
                    uint32_t r = request->requests[i];

                    switch (r) {
                        // Supported requests. Multiboot 2 3.1.4 has a tag whose
                        // information is unavailable left out, required or not.
                        case MULTIBOOT_TAG_TYPE_CMDLINE:
                        case MULTIBOOT_TAG_TYPE_BOOTDEV:
                        case MULTIBOOT_TAG_TYPE_BOOT_LOADER_NAME:
                        case MULTIBOOT_TAG_TYPE_MODULE:
                        case MULTIBOOT_TAG_TYPE_MMAP:
                        case MULTIBOOT_TAG_TYPE_SMBIOS:
                        case MULTIBOOT_TAG_TYPE_BASIC_MEMINFO:
                            break;
                        case MULTIBOOT_TAG_TYPE_EFI_MMAP:
                        case MULTIBOOT_TAG_TYPE_EFI32:
                        case MULTIBOOT_TAG_TYPE_EFI32_IH:
                        case MULTIBOOT_TAG_TYPE_EFI64:
                        case MULTIBOOT_TAG_TYPE_EFI64_IH:
                            break;
                        case MULTIBOOT_TAG_TYPE_FRAMEBUFFER:
                        #if defined (UEFI)
                            is_framebuffer_declared = true;
                        #endif
                            break;
                        case MULTIBOOT_TAG_TYPE_ACPI_NEW:
                        case MULTIBOOT_TAG_TYPE_ACPI_OLD:
                        case MULTIBOOT_TAG_TYPE_ELF_SECTIONS:
                        case MULTIBOOT_TAG_TYPE_LOAD_BASE_ADDR:
                        case MULTIBOOT_TAG_TYPE_NETWORK:
                            break;
                        // The end tag carries no information, so asking for it
                        // asks for nothing.
                        case MULTIBOOT_TAG_TYPE_END: {
                            break;
                        }
                        default:
                            if (is_required)
                                panic(true, "multiboot2: Requested tag `%d` which is not supported", r);
                            break;
                    }
                }
                break;
            }
            case MULTIBOOT_HEADER_TAG_CONSOLE_FLAGS: {
#if defined (UEFI)
                if (tag->size < sizeof(struct multiboot_header_tag_console_flags))
                    break;
                struct multiboot_header_tag_console_flags *flags = (void *)tag;
                console_flags = flags->console_flags;
#endif
                break;
            }
            case MULTIBOOT_HEADER_TAG_FRAMEBUFFER: {
                if (tag->size < sizeof(struct multiboot_header_tag_framebuffer))
                    break;
                fbtag = (void *)tag;
                break;
            }
            case MULTIBOOT_HEADER_TAG_ENTRY_ADDRESS: {
                if (tag->size < sizeof(struct multiboot_header_tag_entry_address))
                    break;
                struct multiboot_header_tag_entry_address *entrytag = (void *)tag;
                entry_point = entrytag->entry_addr;
                break;
            }
            case MULTIBOOT_HEADER_TAG_ADDRESS: {
                if (tag->size < sizeof(struct multiboot_header_tag_address))
                    break;
                addresstag = (void *)tag;
                break;
            }
            // We always align the modules ;^)
            case MULTIBOOT_HEADER_TAG_MODULE_ALIGN:
                break;
            case MULTIBOOT_HEADER_TAG_EFI_BS:
                print("multiboot2: Warning: EFI_BS tag requested but not supported\n");
                if (is_required) {
                    panic(true, "multiboot2: EFI_BS tag is required but not supported");
                }
                break;

            case MULTIBOOT_HEADER_TAG_RELOCATABLE: {
                if (tag->size < sizeof(struct multiboot_header_tag_relocatable))
                    break;
                has_reloc_header = true;
                struct multiboot_header_tag_relocatable *reloc_tag_ptr = (void *)tag;
                reloc_tag = *reloc_tag_ptr;
                break;
            }
            // Both only apply along with the EFI boot services tag, which is
            // never honoured.
            case MULTIBOOT_HEADER_TAG_ENTRY_ADDRESS_EFI32:
            case MULTIBOOT_HEADER_TAG_ENTRY_ADDRESS_EFI64: {
                break;
            }

            default:
                if (is_required) {
                    if (tag->type <= 10 /* max specified ID */) {
                        panic(true, "multiboot2: Unsupported header tag type: %u", tag->type);
                    } else {
                        panic(true, "multiboot2: Unknown custom header tag type: %u", tag->type);
                    }
                } else {
                    if (tag->type > 10) {
                        print("multiboot2: Unknown custom header tag type: %u\n", tag->type);
                    }
                }
        }
        tag = (struct multiboot_header_tag *)((uintptr_t)tag + tag_stride);
    }

#if defined (UEFI)
    // Neither declaration of framebuffer support, so text is all that is left
    // and UEFI has none. After the loop: either may follow the console tag.
    if ((console_flags & 1) && fbtag == NULL && !is_framebuffer_declared) {
        panic(true, "multiboot2: OS requires text mode, but UEFI does not support it");
    }
#endif

    bool section_hdr_info_valid = false;
    struct elf_section_hdr_info section_hdr_info = {0};

    struct elsewhere_range *ranges;
    uint64_t ranges_count = 1;

    if (addresstag != NULL) {
        size_t header_offset = (size_t)header - (size_t)kernel;

        size_t load_src;
        uintptr_t load_addr;
        if (addresstag->load_addr != (uint32_t)-1) {
            if (addresstag->load_addr > addresstag->header_addr) {
                panic(true, "multiboot2: Illegal load address");
            }

            size_t addr_diff = addresstag->header_addr - addresstag->load_addr;
            if (addr_diff > header_offset) {
                panic(true, "multiboot2: Address tag offset underflow");
            }
            load_src = header_offset - addr_diff;
            load_addr = addresstag->load_addr;
        } else {
            if (header_offset > addresstag->header_addr) {
                panic(true, "multiboot2: Header offset exceeds header address");
            }
            load_src = 0;
            load_addr = addresstag->header_addr - header_offset;
        }

        size_t load_size;
        if (addresstag->load_end_addr != 0) {
            if (addresstag->load_end_addr < load_addr) {
                panic(true, "multiboot2: Load end address less than load address");
            }
            load_size = addresstag->load_end_addr - load_addr;
        } else {
            if (load_src > kernel_file_size) {
                panic(true, "multiboot2: Load source exceeds kernel file size");
            }
            load_size = kernel_file_size - load_src;
        }

        size_t bss_size = 0;
        if (addresstag->bss_end_addr != 0) {
            uintptr_t bss_addr = CHECKED_ADD(load_addr, load_size,
                panic(true, "multiboot2: load_addr + load_size overflow"));
            if (addresstag->bss_end_addr < bss_addr) {
                panic(true, "multiboot2: Illegal bss end address");
            }

            bss_size = addresstag->bss_end_addr - bss_addr;
        }

        if (load_src > kernel_file_size || load_size > kernel_file_size - load_src) {
            panic(true, "multiboot2: load_src + load_size exceeds kernel file size");
        }

        size_t full_size = CHECKED_ADD(load_size, bss_size,
            panic(true, "multiboot2: load_size + bss_size overflow"));

        void *elsewhere = ext_mem_alloc(full_size);

        memcpy(elsewhere, kernel + load_src, load_size);

        if (entry_point == 0xffffffff) {
            panic(true, "multiboot2: Using address tag but entry address tag missing");
        }

        ranges = ext_mem_alloc(sizeof(struct elsewhere_range));

        ranges->elsewhere = (uintptr_t)elsewhere;
        ranges->target = load_addr;
        ranges->length = full_size;
    } else {
        uint64_t e;
        int bits = elf_bits(kernel, kernel_file_size);

        switch (bits) {
            case 32:
                if (!elf32_load_elsewhere(kernel, kernel_file_size, 0xffffffff,
                                          &e, &ranges))
                    panic(true, "multiboot2: ELF32 load failure");

                section_hdr_info = elf32_section_hdr_info(kernel, kernel_file_size);
                section_hdr_info_valid = true;
                break;
            case 64: {
                if (!elf64_load_elsewhere(kernel, kernel_file_size, 0xffffffff,
                                          &e, &ranges))
                    panic(true, "multiboot2: ELF64 load failure");

                section_hdr_info = elf64_section_hdr_info(kernel, kernel_file_size);
                section_hdr_info_valid = true;
                break;
            }
            default:
                panic(true, "multiboot2: Invalid ELF file bitness");
        }

        if (entry_point == 0xffffffff) {
            entry_point = e;
        }
    }

    int64_t reloc_slide = 0;

    if (has_reloc_header) {
        // Multiboot 2 gives align 0 no meaning; take it as no constraint.
        if (reloc_tag.align == 0) {
            reloc_tag.align = 1;
        }

        // Page 0 sits at the null pointer; keep the image out of it, whatever
        // min_addr allows.
        if (reloc_tag.min_addr < 0x1000) {
            reloc_tag.min_addr = 0x1000;
        }

        bool reloc_ascend;
        uint64_t relocated_base;

        switch (reloc_tag.preference) {
            default:
            case 0: case 1: // No preference / prefer lowest
                reloc_ascend = true;
                relocated_base = ALIGN_UP(reloc_tag.min_addr, reloc_tag.align, goto reloc_fail);
                if (CHECKED_ADD(relocated_base, ranges->length, goto reloc_fail) > reloc_tag.max_addr) {
                    goto reloc_fail;
                }
                break;
            case 2: // Prefer highest
                reloc_ascend = false;
                if (ranges->length > reloc_tag.max_addr) {
                    goto reloc_fail;
                }
                relocated_base = ALIGN_DOWN(reloc_tag.max_addr - ranges->length, reloc_tag.align);
                if (relocated_base < reloc_tag.min_addr) {
                    goto reloc_fail;
                }
                break;
        }

        // A small align turns this into a byte-by-byte walk, each step scanning
        // the memory map. The cap bounds that work, and below page alignment it
        // bounds the reach with it.
        uint64_t reloc_tries = 0;

        for (;;) {
            uint64_t relocated_top = CHECKED_ADD(relocated_base, ranges->length, goto reloc_fail);

            if (check_usable_memory(relocated_base, relocated_top)
             && !overlaps_loader_memory(relocated_base, relocated_top)) {
                break;
            }

            if (++reloc_tries > 0x100000) {
                goto reloc_fail;
            }

            if (reloc_ascend) {
                relocated_base += reloc_tag.align;
                if (CHECKED_ADD(relocated_base, ranges->length, goto reloc_fail) > reloc_tag.max_addr) {
                    goto reloc_fail;
                }
            } else {
                if (relocated_base - reloc_tag.min_addr < reloc_tag.align) {
                    goto reloc_fail;
                }
                relocated_base -= reloc_tag.align;
            }
        }

        reloc_slide = (int64_t)relocated_base - ranges->target;

        entry_point += reloc_slide;

        ranges->target = relocated_base;
    }

    // multiboot_reloc_stub reads the range fields with 32-bit loads, so a
    // target or length it cannot hold is truncated rather than refused.
    if (ranges->target > 0x100000000
     || ranges->length > 0xffffffff
     || ranges->length > 0x100000000 - ranges->target) {
        panic(true, "multiboot2: Executable does not fit under 4GiB");
    }

    if (!check_usable_memory(ranges->target, ranges->target + ranges->length)) {
reloc_fail:
        panic(true, "multiboot2: Could not find viable load address for executable");
    }

    if (entry_point < ranges->target
     || entry_point >= ranges->target + ranges->length) {
        panic(true, "multiboot2: Entry point is outside the executable");
    }

    // Reserve the kernel's target so later module/info sources can't be
    // allocated on top of it.
    elsewhere_reserve_target(ranges->target, ranges->length);

    // Get the load base address (AKA the lowest target in the ranges)
    uint64_t load_base_addr = ranges->target;

    size_t modules_size = 0;
    size_t n_modules;

    for (n_modules = 0;; n_modules++) {
        struct conf_tuple conf_tuple = config_get_tuple(config, n_modules, "MODULE_PATH", "MODULE_STRING");
        if (!conf_tuple.value1) break;

        char *module_cmdline = conf_tuple.value2;
        if (!module_cmdline) module_cmdline = "";
        modules_size += ALIGN_UP(sizeof(struct multiboot_tag_module) + strlen(module_cmdline) + 1, MULTIBOOT_TAG_ALIGN, panic(true, "multiboot2: modules size overflow"));
    }

    struct smbios_entry_point_32* smbios_entry_32 = NULL;
    struct smbios_entry_point_64* smbios_entry_64 = NULL;

    acpi_get_smbios((void **)&smbios_entry_32, (void **)&smbios_entry_64);

    // The tag holds the structure table each entry point points at.
    void *smbios_table_32 = NULL, *smbios_table_64 = NULL;
    uint32_t smbios_table_32_size = 0, smbios_table_64_size = 0;
    if (smbios_entry_32 != NULL) {
        smbios_table_32 = smbios_get_table(smbios_entry_32->table_address, smbios_entry_32->table_length);
        smbios_table_32_size = smbios_entry_32->table_length;
    }
    if (smbios_entry_64 != NULL) {
        smbios_table_64 = smbios_get_table(smbios_entry_64->table_address, smbios_entry_64->table_maximum_size);
        smbios_table_64_size = smbios_entry_64->table_maximum_size;
    }

    uint32_t smbios_tag_size = 0;

    if (smbios_table_32 != NULL)
        smbios_tag_size += ALIGN_UP(sizeof(struct multiboot_tag_smbios) + smbios_table_32_size, MULTIBOOT_TAG_ALIGN, panic(true, "multiboot2: tag size overflow"));
    if (smbios_table_64 != NULL)
        smbios_tag_size += ALIGN_UP(sizeof(struct multiboot_tag_smbios) + smbios_table_64_size, MULTIBOOT_TAG_ALIGN, panic(true, "multiboot2: tag size overflow"));

    size_t mb2_info_size = get_multiboot2_info_size(
        cmdline,
        modules_size,
        section_hdr_info_valid ? section_hdr_info.section_entry_size : 0,
        section_hdr_info_valid ? section_hdr_info.num : 0,
        smbios_tag_size
    );

    size_t info_idx = 0;

    // Realloc elsewhere ranges to include mb2 info, modules, and elf sections
    uint64_t ranges_max = ranges_count
       + 1 /* mb2 info range */
       + n_modules
       + (section_hdr_info_valid ? section_hdr_info.num : 0);
    struct elsewhere_range *new_ranges = ext_mem_alloc_counted(ranges_max, sizeof(struct elsewhere_range));

    memcpy(new_ranges, ranges, sizeof(struct elsewhere_range) * ranges_count);
    pmm_free(ranges, sizeof(struct elsewhere_range) * ranges_count);
    ranges = new_ranges;

    // GRUB allocates boot info at 0x10000, *except* if the kernel happens
    // to overlap this region, then it gets moved to right after the
    // kernel, or whichever PHDR happens to sit at 0x10000.
    // Allocate it wherever, then move it to where GRUB puts it
    // afterwards.

    // Elsewhere append mb2 info *after* kernel but *before* modules.
    uint8_t *mb2_info = ext_mem_alloc(mb2_info_size);
    uint64_t mb2_info_final_loc = 0x10000;

    if (!elsewhere_append(has_reloc_header,
            ranges, &ranges_count, ranges_max,
            mb2_info, &mb2_info_final_loc, mb2_info_size)) {
        panic(true, "multiboot2: Cannot allocate mb2 info");
    }

    struct multiboot2_start_tag *mbi_start = (struct multiboot2_start_tag *)mb2_info;
    info_idx += sizeof(struct multiboot2_start_tag);

    //////////////////////////////////////////////
    // Create ELF info tag
    //////////////////////////////////////////////
    if (section_hdr_info_valid) {
        size_t section_table_size = CHECKED_MUL(section_hdr_info.section_entry_size, section_hdr_info.num,
            panic(true, "multiboot2: ELF section table size overflow"));
        if (section_hdr_info.section_offset > kernel_file_size ||
            section_table_size > kernel_file_size - section_hdr_info.section_offset) {
            panic(true, "multiboot2: ELF section headers out of bounds");
        }

        uint32_t size = sizeof(struct multiboot_tag_elf_sections) + section_table_size;
        struct multiboot_tag_elf_sections *tag = (struct multiboot_tag_elf_sections*)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_ELF_SECTIONS;
        tag->size = size;

        tag->num = section_hdr_info.num;
        tag->entsize = section_hdr_info.section_entry_size;
        tag->shndx = section_hdr_info.str_section_idx;

        memcpy(tag->sections, kernel + section_hdr_info.section_offset, section_table_size);

        int bits = elf_bits(kernel, kernel_file_size);

        // No sections means no stride to check; the walk below cannot run.
        if (section_hdr_info.num != 0
         && ((bits == 64 && section_hdr_info.section_entry_size < sizeof(struct elf64_shdr))
          || (bits == 32 && section_hdr_info.section_entry_size < sizeof(struct elf32_shdr)))) {
            panic(true, "multiboot2: ELF section entry size too small");
        }

        // Section header 0 describes no section, and under extended numbering
        // its sh_size is the section count.
        for (size_t i = 1; i < section_hdr_info.num; i++) {
            if (bits == 64)  {
                struct elf64_shdr *shdr = (void *)tag->sections + i * section_hdr_info.section_entry_size;

                if (shdr->sh_addr != 0) {
                    shdr->sh_addr += reloc_slide;
                    continue;
                }
                if (shdr->sh_size == 0) {
                    continue;
                }

                if (shdr->sh_offset > kernel_file_size ||
                    shdr->sh_size > kernel_file_size - shdr->sh_offset) {
                    continue;
                }

                uint64_t section = (uint64_t)-1; /* no target preference, use top */

                if (!elsewhere_append(has_reloc_header,
                        ranges, &ranges_count, ranges_max,
                        kernel + shdr->sh_offset, &section, shdr->sh_size)) {
                    panic(true, "multiboot2: Cannot allocate elf sections");
                }

                shdr->sh_addr = section;
            } else {
                struct elf32_shdr *shdr = (void *)tag->sections + i * section_hdr_info.section_entry_size;

                if (shdr->sh_addr != 0) {
                    shdr->sh_addr += (int32_t)reloc_slide;
                    continue;
                }
                if (shdr->sh_size == 0) {
                    continue;
                }

                if (shdr->sh_offset > kernel_file_size ||
                    shdr->sh_size > kernel_file_size - shdr->sh_offset) {
                    continue;
                }

                uint64_t section = (uint64_t)-1; /* no target preference, use top */

                if (!elsewhere_append(has_reloc_header,
                        ranges, &ranges_count, ranges_max,
                        kernel + shdr->sh_offset, &section, shdr->sh_size)) {
                    panic(true, "multiboot2: Cannot allocate elf sections");
                }

                shdr->sh_addr = section;
            }
        }

        append_tag(info_idx, tag);
    }

    //////////////////////////////////////////////
    // Create load base address tag
    //////////////////////////////////////////////
    // GRUB gives it to every executable, not only relocatable ones as
    // Multiboot2 2.0 section 3.6.23 has it.
    {
        uint32_t size = sizeof(struct multiboot_tag_load_base_addr);
        struct multiboot_tag_load_base_addr *tag = (void *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_LOAD_BASE_ADDR;
        tag->size = size;

        tag->load_base_addr = load_base_addr;

        append_tag(info_idx, tag);
    }

    //////////////////////////////////////////////
    // Create modules tag
    //////////////////////////////////////////////
    for (size_t i = 0; i < n_modules; i++) {
        struct conf_tuple conf_tuple = config_get_tuple(config, i, "MODULE_PATH", "MODULE_STRING");
        char *module_path = conf_tuple.value1;
        if (!module_path) panic(true, "multiboot2: Module disappeared unexpectedly");

        if (!terse) {
            print("multiboot2: Loading module `%#`...\n", module_path);
        }

        struct file_handle *f;
        if ((f = uri_open(module_path, MEMMAP_BOOTLOADER_RECLAIMABLE, false
#if defined (__i386__)
            , NULL, NULL
#endif
        )) == NULL)
            panic(true, "multiboot2: Failed to open module with path `%#`. Is the path correct?", module_path);

        // Module commandline can be null, so we guard against that and make the
        // string "".
        char *module_cmdline = conf_tuple.value2;
        if (!module_cmdline) module_cmdline = "";

        void *module_addr = f->fd;
        uint64_t module_target = (uint64_t)-1;

#if defined (UEFI)
        tpm_measure_path(TPM_PCR_BOOT_AUTH, TPM_EV_IPL, "module_path: ", module_path);
        tpm_measure(TPM_PCR_LOADED_IMAGES, TPM_EV_IPL,
                    module_addr, f->size, "module_path: ", module_path);
#endif

        if (!elsewhere_append(has_reloc_header,
                ranges, &ranges_count, ranges_max,
                module_addr, &module_target, f->size)) {
            panic(true, "multiboot2: Cannot allocate module");
        }

        struct multiboot_tag_module *module_tag = (struct multiboot_tag_module *)(mb2_info + info_idx);

        module_tag->type = MULTIBOOT_TAG_TYPE_MODULE;
        module_tag->size = sizeof(struct multiboot_tag_module) + strlen(module_cmdline) + 1;
        module_tag->mod_start   = module_target;
        module_tag->mod_end     = module_tag->mod_start + f->size;
        strcpy(module_tag->cmdline, module_cmdline); // Copy over the command line

        fclose(f);

        if (verbose) {
            print("multiboot2: Requested module %u:\n", (uint32_t)i);
            print("            Path:   %s\n", module_path);
            print("            String: \"%s\"\n", module_cmdline ?: "");
            print("            Begin:  %x\n", module_tag->mod_start);
            print("            End:    %x\n", module_tag->mod_end);
        }

        append_tag(info_idx, module_tag);
    }

    //////////////////////////////////////////////
    // Create command line tag
    //////////////////////////////////////////////
    {
        uint32_t size = sizeof(struct multiboot_tag_string) + strlen(cmdline) + 1;
        struct multiboot_tag_string *tag = (struct multiboot_tag_string *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_CMDLINE;
        tag->size = size;

        strcpy(tag->string, cmdline);
        append_tag(info_idx, tag);
    }

    //////////////////////////////////////////////
    // Create bootloader name tag
    //////////////////////////////////////////////
    {
        uint32_t size = sizeof(struct multiboot_tag_string) + sizeof(LIMINE_BRAND);
        struct multiboot_tag_string *tag = (struct multiboot_tag_string *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_BOOT_LOADER_NAME;
        tag->size = size;

        strcpy(tag->string, LIMINE_BRAND);
        append_tag(info_idx, tag);
    }

    //////////////////////////////////////////////
    // Create BIOS boot device tag
    //////////////////////////////////////////////
#if defined (BIOS)
    // The 0-based partition, all ones where unused (Multiboot2 2.0 section
    // 3.6.4).
    if (kernel_volume != NULL) {
        struct multiboot_tag_bootdev *tag = (struct multiboot_tag_bootdev *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_BOOTDEV;
        tag->size = sizeof(struct multiboot_tag_bootdev);
        tag->biosdev = (uint32_t)kernel_volume->drive & 0xff;
        tag->slice = kernel_volume->partition == 0 ? 0xffffffff : (uint32_t)(kernel_volume->partition - 1);
        tag->part = 0xffffffff;

        append_tag(info_idx, tag);
    }
#endif

    //////////////////////////////////////////////
    // Create framebuffer tag
    //////////////////////////////////////////////
    {
        struct multiboot_tag_framebuffer *tag = (struct multiboot_tag_framebuffer *)(mb2_info + info_idx);

        tag->common.type = MULTIBOOT_TAG_TYPE_FRAMEBUFFER;

        term_notready();

        size_t req_width = 0;
        size_t req_height = 0;
        size_t req_bpp = 0;
#if defined (BIOS)
        {
            char *textmode_str = config_get_value(config, 0, "TEXTMODE");
            bool textmode = textmode_str != NULL && strcmp(textmode_str, "yes") == 0;
            if (textmode) {
                goto textmode;
            }
        }
#endif

        if (fbtag) {
            req_width = fbtag->width;
            req_height = fbtag->height;
            req_bpp = fbtag->depth;

#if defined (UEFI)
modeset:;
#endif
            char *resolution = config_get_value(config, 0, "RESOLUTION");
            if (resolution != NULL)
                parse_resolution(&req_width, &req_height, &req_bpp, resolution);

            struct fb_info *fbs;
            size_t fbs_count;
            fb_init(&fbs, &fbs_count, req_width, req_height, req_bpp, false, false);
            if (fbs_count == 0) {
#if defined (BIOS)
textmode:
                vga_textmode_init(false);

                tag->common.framebuffer_addr = 0xb8000;
                tag->common.framebuffer_pitch = 2 * 80;
                tag->common.framebuffer_width = 80;
                tag->common.framebuffer_height = 25;
                tag->common.framebuffer_bpp = 16;
                tag->common.framebuffer_type = MULTIBOOT_FRAMEBUFFER_TYPE_EGA_TEXT;
                tag->common.size = sizeof(struct multiboot_tag_framebuffer_common);
#elif defined (UEFI)
                // Bit 0 makes a console mandatory, and none can be provided here.
                if (console_flags & 1) {
                    panic(true, "multiboot2: Failed to set video mode");
                } else {
                    goto skip_modeset;
                }
#endif
            } else {
                tag->common.framebuffer_addr = fbs[0].framebuffer_addr;
                tag->common.framebuffer_pitch = fbs[0].framebuffer_pitch;
                tag->common.framebuffer_width = fbs[0].framebuffer_width;
                tag->common.framebuffer_height = fbs[0].framebuffer_height;
                tag->common.framebuffer_bpp = fbs[0].framebuffer_bpp;
                tag->common.framebuffer_type = MULTIBOOT_FRAMEBUFFER_TYPE_RGB; // We only support RGB for VBE
                // 6 bytes of colour info; size leaves out the padding after them.
                tag->common.size = sizeof(struct multiboot_tag_framebuffer_common) + 6;

                tag->framebuffer_red_field_position = fbs[0].red_mask_shift;
                tag->framebuffer_red_mask_size = fbs[0].red_mask_size;
                tag->framebuffer_green_field_position = fbs[0].green_mask_shift;
                tag->framebuffer_green_mask_size = fbs[0].green_mask_size;
                tag->framebuffer_blue_field_position = fbs[0].blue_mask_shift;
                tag->framebuffer_blue_mask_size = fbs[0].blue_mask_size;
            }
        } else {
#if defined (UEFI)
            // As GRUB does, set no mode nobody asked for. Only a required
            // console, which can only be a framebuffer here, asks for one.
            if ((console_flags & 1) && is_framebuffer_declared) {
                goto modeset;
            }
            goto skip_modeset;
#elif defined (BIOS)
            goto textmode;
#endif
        }

        append_tag(info_idx, &tag->common);

#if defined (UEFI)
skip_modeset:;
#endif
    }

    //////////////////////////////////////////////
    // Create new ACPI info tag
    //////////////////////////////////////////////
    {
        void *new_rsdp = acpi_get_rsdp_v2();

        if (new_rsdp != NULL) {
            uint32_t size = sizeof(struct multiboot_tag_new_acpi) + sizeof(struct rsdp); // XSDP is 36 bytes wide
            struct multiboot_tag_new_acpi *tag = (struct multiboot_tag_new_acpi *)(mb2_info + info_idx);

            tag->type = MULTIBOOT_TAG_TYPE_ACPI_NEW;
            tag->size = size;

            memcpy(tag->rsdp, new_rsdp, sizeof(struct rsdp));
            append_tag(info_idx, tag);
        }
    }

    //////////////////////////////////////////////
    // Create old ACPI info tag
    //////////////////////////////////////////////
    {
        void *old_rsdp = acpi_get_rsdp_v1();

        if (old_rsdp != NULL) {
            uint32_t size = sizeof(struct multiboot_tag_old_acpi) + 20; // RSDP is 20 bytes wide
            struct multiboot_tag_old_acpi *tag = (struct multiboot_tag_old_acpi *)(mb2_info + info_idx);

            tag->type = MULTIBOOT_TAG_TYPE_ACPI_OLD;
            tag->size = size;

            memcpy(tag->rsdp, old_rsdp, 20);
            append_tag(info_idx, tag);
        }
    }

    //////////////////////////////////////////////
    // Create SMBIOS tag
    //////////////////////////////////////////////
    {
        // NOTE: The multiboot2 specification does not say anything about if both
        // smbios 32 and 64 bit entry points are present, then we pass both of them + smbios
        // support for grub2 is unimplemented. So, we are going to assume they expect us to
        // pass both of them if available. Oh well...
        if (smbios_table_32 != NULL) {
            struct multiboot_tag_smbios *tag = (struct multiboot_tag_smbios *)(mb2_info + info_idx);

            tag->type = MULTIBOOT_TAG_TYPE_SMBIOS;
            tag->size = sizeof(struct multiboot_tag_smbios) + smbios_table_32_size;

            tag->major = smbios_entry_32->major_version;
            tag->minor = smbios_entry_32->minor_version;

            memset(tag->reserved, 0, 6);
            memcpy(tag->tables, smbios_table_32, smbios_table_32_size);

            append_tag(info_idx, tag);
        }

        if (smbios_table_64 != NULL) {
            struct multiboot_tag_smbios *tag = (struct multiboot_tag_smbios *)(mb2_info + info_idx);

            tag->type = MULTIBOOT_TAG_TYPE_SMBIOS;
            tag->size = sizeof(struct multiboot_tag_smbios) + smbios_table_64_size;

            tag->major = smbios_entry_64->major_version;
            tag->minor = smbios_entry_64->minor_version;

            memset(tag->reserved, 0, 6);
            memcpy(tag->tables, smbios_table_64, smbios_table_64_size);

            append_tag(info_idx, tag);
        }
    }

    //////////////////////////////////////////////
    // Create EFI system table info tag
    //////////////////////////////////////////////
#if defined (UEFI)
    {
    #if defined (__i386__)
        uint32_t size = sizeof(struct multiboot_tag_efi32);
        struct multiboot_tag_efi32 *tag = (void *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_EFI32;
    #elif defined (__x86_64__)
        uint32_t size = sizeof(struct multiboot_tag_efi64);
        struct multiboot_tag_efi64 *tag = (void *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_EFI64;
    #endif

        tag->size = size;
        tag->pointer = (uintptr_t)gST;

        append_tag(info_idx, tag);
    }
#endif

    // Load relocation stub where it won't get overwritten (hopefully)
    size_t reloc_stub_size = (size_t)multiboot_reloc_stub_end - (size_t)multiboot_reloc_stub;
    void *reloc_stub = ext_mem_alloc(reloc_stub_size);
    memcpy(reloc_stub, multiboot_reloc_stub, reloc_stub_size);

#if defined (UEFI)
    efi_exit_boot_services();
#endif

    size_t mb_mmap_count;
    struct memmap_entry *raw_memmap = get_raw_memmap(&mb_mmap_count);

    //////////////////////////////////////////////
    // Create memory map tag
    //////////////////////////////////////////////
    {
        if (mb_mmap_count > MEMMAP_MAX) {
            panic(false, "multiboot2: too many memory map entries");
        }

        // Create the normal memory map tag.
        uint32_t mmap_size = sizeof(struct multiboot_tag_mmap) + sizeof(struct multiboot_mmap_entry) * mb_mmap_count;
        struct multiboot_tag_mmap *mmap_tag = (struct multiboot_tag_mmap *)(mb2_info + info_idx);

        mmap_tag->type = MULTIBOOT_TAG_TYPE_MMAP;
        mmap_tag->entry_size = sizeof(struct multiboot_mmap_entry);
        mmap_tag->entry_version = 0;
        mmap_tag->size = mmap_size;

        for (size_t i = 0; i < mb_mmap_count; i++) {
            struct multiboot_mmap_entry *entry = &mmap_tag->entries[i];
            entry->addr = raw_memmap[i].base;
            entry->len  = raw_memmap[i].length;
            entry->type = raw_memmap[i].type;
            entry->zero = 0;
        }

        append_tag(info_idx, mmap_tag);
    }

    //////////////////////////////////////////////
    // Create basic memory info tag
    //////////////////////////////////////////////
    {
        struct meminfo meminfo = mmap_get_info(mb_mmap_count, raw_memmap);
        struct multiboot_tag_basic_meminfo *tag = (struct multiboot_tag_basic_meminfo *)(mb2_info + info_idx);

        tag->type = MULTIBOOT_TAG_TYPE_BASIC_MEMINFO;
        tag->size = sizeof(struct multiboot_tag_basic_meminfo);

        // Convert the uppermem and lowermem fields from bytes to
        // KiB.
        tag->mem_upper = (uint32_t)(meminfo.uppermem / 1024);
        tag->mem_lower = (uint32_t)(meminfo.lowermem / 1024);

        append_tag(info_idx, tag);
    }

    //////////////////////////////////////////////
    // Create EFI memory map tag
    //////////////////////////////////////////////
#if defined (UEFI)
    {
        if ((efi_mmap_size / efi_desc_size) > EFI_MEMMAP_MAX) {
            panic(false, "multiboot2: too many EFI memory map entries");
        }

        // Create the EFI memory map tag.
        uint32_t size = sizeof(struct multiboot_tag_efi_mmap) + efi_mmap_size;
        struct multiboot_tag_efi_mmap *mmap_tag = (struct multiboot_tag_efi_mmap *)(mb2_info + info_idx);

        mmap_tag->type = MULTIBOOT_TAG_TYPE_EFI_MMAP;
        mmap_tag->descr_vers = efi_desc_ver;
        mmap_tag->descr_size = efi_desc_size;
        mmap_tag->size = size;

        // Copy over the EFI memory map.
        memcpy(mmap_tag->efi_mmap, efi_mmap, efi_mmap_size);
        append_tag(info_idx, mmap_tag);
    }
#endif

    //////////////////////////////////////////////
    // Create network info tag
    //////////////////////////////////////////////
    {
        if (cached_dhcp_ack_valid) {
            struct multiboot_tag_network *tag = (struct multiboot_tag_network *)(mb2_info + info_idx);

            tag->type = MULTIBOOT_TAG_TYPE_NETWORK;
            tag->size = sizeof(struct multiboot_tag_network) + cached_dhcp_packet_len;

            // Copy over the DHCP packet.
            memcpy(tag->dhcpack, cached_dhcp_packet, cached_dhcp_packet_len);
            append_tag(info_idx, tag);
        }
    }

    //////////////////////////////////////////////
    // Create end tag
    //////////////////////////////////////////////
    {
        struct multiboot_tag *end_tag = (struct multiboot_tag *)(mb2_info + info_idx);
        end_tag->type = MULTIBOOT_TAG_TYPE_END;
        end_tag->size = sizeof(struct multiboot_tag);

        append_tag(info_idx, end_tag);
    }

    mbi_start->size = info_idx;
    mbi_start->reserved = 0x00;

    if (rdmsr(0x1b) & (1 << 10)) {
        if (x2apic_disable()) {
            printv("multiboot2: Firmware had x2APIC enabled, reverted to xAPIC mode\n");
        } else {
            printv("multiboot2: Firmware has x2APIC enabled and it could not be disabled\n");
        }
    }

    iommu_disable_all();

    irq_flush_type = IRQ_PIC_ONLY_FLUSH;

#if defined (UEFI) && defined (__x86_64__)
    void *spinup_fn = spinup_tramp_low(multiboot_spinup_32);
#else
    void *spinup_fn = multiboot_spinup_32;
#endif

    common_spinup(spinup_fn, 6,
                  (uint32_t)(uintptr_t)reloc_stub, (uint32_t)0x36d76289,
                  (uint32_t)mb2_info_final_loc, (uint32_t)entry_point,
                  (uint32_t)(uintptr_t)ranges, (uint32_t)ranges_count);
}

#endif
